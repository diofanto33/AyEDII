#include "list.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>

struct _list
{
    struct _node* head;
    ListSize size;
};

struct _node
{
    elem e;
    struct _node* next;
};

/**
 * @brief Invariante de represetación
 *
 * @param l Lista
 * @return true Si l es una lista válida
 * @return false Si l NO es una lista válida
 */
static bool invrep(list l)
{
    // COMPLETE AQUI
    return l != NULL || l == NULL;  // Para que compile, REMOVER
}

/**
 * @brief Crea un nodo de la lista nuevo
 *
 * @param e Elemento que contendrá el nodo
 * @return struct _node* Nuevo nodo creado o NULL si no hay memoria
 */
static struct _node* create_node(elem e)
{
    struct _node* res = malloc(sizeof(struct _node));
    if (res != NULL)
    {
        res->e = e;
        res->next = NULL;
    }
    return res;
}

/**
 * @brief Destruye el nodo node
 *
 * @param node Nodo a ser destruido
 * @return struct _node* Devuelve NULL si el nodo se destruyó correctamente
 */
static struct _node* destroy_node(struct _node* node)
{
    if (node != NULL)
    {
        free(node);
        node = NULL;
    }
    assert(node == NULL);
    return node;
}

list list_empty()
{
    list res = NULL;
    // COMPLETE AQUI
    assert(invrep(res));
    return res;
}

list list_addl(list l, elem e)
{
    assert(invrep(l));
    // COMPLETE AQUI
    assert(invrep(l));
    return l;
}

list list_addr(list l, elem e)
{
    assert(invrep(l));
    // COMPLETE AQUI
    assert(invrep(l));
    return l;
}

bool list_is_empty(list l)
{
    assert(l != NULL && invrep(l));
    // COMPLETE AQUI
    return l != NULL;  // BORRAR ESTA LINEA
}

elem list_head(list l)
{
    assert(l != NULL && invrep(l) && !list_is_empty(l));
    // COMPLETE AQUI
    return 0u;  // BORRAR ESTA LINEA
}

list list_tail(list l)
{
    assert(!list_is_empty(l));
    // COMPLETE AQUI
    return l;
}

ListSize list_length(list l)
{
    assert(l != NULL);
    // COMPLETE AQUI
    return l->size;
}

void list_print(list l)
{
    // COMPLETE AQUI
}

list list_destroy(list l)
{
    assert(l != NULL && invrep(l));
    // COMPLETE AQUI
    return l;
}

/* Funciones Anexas */

list list_greater_than(list l, unsigned int n)
{
    // COMPLETE AQUI
}

unsigned int list_greater_than_count(list l, unsigned int n)
{
    // COMPLETE AQUI
}

list list_insert_at(list l, unsigned int position, elem e)
{
    // COMPLETE AQUI
}